const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

let previousNumbers = null;

app.use(bodyParser.json());

app.get('/getRandomNumbers', (req, res) => {
    const newNumbers = generateUniqueNumbers();
    previousNumbers = newNumbers;
    res.json(newNumbers);
});

function generateUniqueNumbers() {
    let numbers, powerball;

    do {
        numbers = Array.from({ length: 5 }, () => Math.floor(Math.random() * 69) + 1);
        powerball = Math.floor(Math.random() * 26) + 1;
    } while (areNumbersEqual(previousNumbers, { numbers, powerball }));

    return { numbers, powerball };
}

function areNumbersEqual(prev, current) {
    if (!prev) return false;

    const prevNumbers = prev.numbers;
    const currentNumbers = current.numbers;

    const isEqual = prevNumbers.every((num, index) => num === currentNumbers[index]);

    return isEqual && prev.powerball === current.powerball;
}

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
